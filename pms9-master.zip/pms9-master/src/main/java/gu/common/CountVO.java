package gu.common;

public class CountVO {
    private String field1;
    private Integer cnt1;
    
    public String getField1() {
        return field1;
    }
    
    public void setField1(String field1) {
        this.field1 = field1;
    }
    
    public Integer getCnt1() {
        return cnt1;
    }
    
    public void setCnt1(Integer cnt1) {
        this.cnt1 = cnt1;
    }
    
    
}
